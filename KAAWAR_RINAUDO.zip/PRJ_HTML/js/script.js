function evaluerSante() {
  let score = 0;

  const form = new FormData(document.getElementById("healthForm"));

  score += parseInt(form.get("q1") || 0);
  score += parseInt(form.get("q3") || 0);
  score += parseInt(form.get("q4") || 0);
  score += parseInt(form.get("q6") || 0);
  score += parseInt(form.get("q7") || 0);

  let checkboxes2 = document.querySelectorAll("input[name='q2']:checked");
  checkboxes2.forEach(cb => score += parseInt(cb.value));

  let checkboxes5 = document.querySelectorAll("input[name='q5']:checked");
  checkboxes5.forEach(cb => score += parseInt(cb.value));

  const energy = parseInt(form.get("q8")) || 0;
  score += energy;

  let totalScore = Math.min(score, 100);


  document.querySelectorAll(".result-table").forEach(div => div.classList.add("hidden"));


  if (totalScore <= 30) {
    document.getElementById("result-low").classList.remove("hidden");
    document.getElementById("score-low").textContent = totalScore;
  } else if (totalScore <= 60) {
    document.getElementById("result-mid").classList.remove("hidden");
    document.getElementById("score-mid").textContent = totalScore;
  } else {
    document.getElementById("result-high").classList.remove("hidden");
    document.getElementById("score-high").textContent = totalScore;
  }
}
