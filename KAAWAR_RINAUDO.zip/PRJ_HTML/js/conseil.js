function lancerDefilementPhrases() {
  const phrases = [
    "Bouger un peu chaque jour, c'est déjà beaucoup.",
    "Respirez profondément, vous êtes vivant.",
    "Votre santé mentale mérite autant d'attention que votre santé physique.",
    "Mangez sainement, dormez suffisamment, souriez souvent.",
    "Prenez soin de vous, personne ne peut le faire à votre place."
  ];

  let index = 0;
  const box = document.getElementById("phrase-box");

  if (box) {
    setInterval(() => {
      box.style.opacity = 0;
      setTimeout(() => {
        index = (index + 1) % phrases.length;
        box.textContent = phrases[index];
        box.style.opacity = 1;
      }, 250);
    }, 2500);
  }
}

document.addEventListener("DOMContentLoaded", lancerDefilementPhrases);
