function ajouterTemoignage() {
  const prenom = document.getElementById("prenom").value.trim();
  const nom = document.getElementById("nom").value.trim();
  const age = document.getElementById("age").value.trim();
  const profession = document.getElementById("profession").value.trim();
  const texte = document.getElementById("nouveau-temoignage").value.trim();

  if (!prenom || !nom || !age || !profession || !texte) {
    alert("Merci de remplir tous les champs.");
    return;
  }

  const nouveauTemoignage = document.createElement("div");
  nouveauTemoignage.classList.add("temoignage");

  nouveauTemoignage.innerHTML = `
    <div class="temoignage-texte">
      <p>"${texte}"</p>
      <p class="temoignage-info"><strong>${prenom} ${nom}</strong> – ${age} ans, ${profession}</p>
    </div>
  `;

  const sectionTemoignages = document.querySelector(".temoignage-section");
  sectionTemoignages.appendChild(nouveauTemoignage);


  document.getElementById("prenom").value = "";
  document.getElementById("nom").value = "";
  document.getElementById("age").value = "";
  document.getElementById("profession").value = "";
  document.getElementById("nouveau-temoignage").value = "";
}


function envoyerFormulaire() {
  const form = document.getElementById('contactForm');
  alert('Message envoyé !');
  form.reset();
}

